GOLANALIZ KORE - TEST KURULUMU

DURUM: Deneme sistemi. Kaynak belgelerde K League 1 ve 2 icin 2026 indirme adresleri var, ancak servis gercek veri donuyor mu ve kolonlari uygun mu HENUZ DOGRULANMADI.

1. GitHub'daki golanaliz-kore reposunda Upload files ekranina update_korea.py dosyasini yukle ve Commit changes bas.
2. .github/workflows/update-korea.yml dosyasi klasor yolu korunarak yuklenmeli. Telefon tarayicisinda klasor yolu korunmazsa repo > Add file > Create new file sec; ad alanina '.github/workflows/update-korea.yml' yaz ve dosyanin icerigini yapistir.
3. Actions > Kore fiksturunu guncelle > Run workflow ile dene.
4. Yesil ise repo kokunde korea_fixtures.json olusur. Kirmizi ise Actions > run > Fetch and validate adimindan hatayi gor. Hata durumunda hicbir uydurma mac yayimlanmaz.
5. Dosya olusursa ham veri adresi: https://raw.githubusercontent.com/yusufkorkmaz160-creator/golanaliz-kore/main/korea_fixtures.json
6. GolAnaliz HTML'ye otomatik entegrasyon icin once bu JSON'un gercekten olustugunu ve dogru fiksturu gosterdigini teyit etmeliyiz.

NOT: GitHub Actions schedule kesin zaman garantisi vermez; bazen gecikebilir. Bu prototip 2026 sezonu icin hazirlandi.
